import Button from "./Button";
import { Bell, Search, Sparkles } from "lucide-react";
import { useGameStore } from "../store";
const titles: Record<string,string>={home:"Command overview",headquarters:"Collider headquarters",circuit:"Quantum switchboard",characters:"Personnel files",story:"Mission control",experiments:"Experiment studio",boss:"Containment encounters",profile:"Researcher profile"};
export default function Topbar(){
 const {screen,player}=useGameStore();
 return <header className="topbar"><div><div className="eyebrow">CERN-ADJACENT // RELATIONSHIP CONTAINMENT DIVISION</div><h1>{titles[screen]??"Laboratory"}</h1></div>
 <div className="top-actions"><div className="top-stat"><Sparkles size={15}/><b>{player.researchPoints.toLocaleString()}</b><span>RP</span></div><div className="top-stat pink"><span>✦</span><b>{player.quantumShards}</b><span>SHARDS</span></div><Button className="icon-button" aria-label="Notifications"><Bell size={17}/><i/></Button><Button className="search-button"><Search size={15}/> Search lab</Button></div></header>;
}
