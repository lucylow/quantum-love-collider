export const dialoguePack02 = {
  id: "dialogue-pack-02",
  title: "Collider incident transcript 02",
  lines: [
    { speaker: "Evie", text: "Let's define the system boundary before this becomes a metaphor." },
    { speaker: "Maya", text: "The system boundary is my patience, and it is not stable." },
    { speaker: "B.R.A.D.", text: "I HAVE UPDATED THE CRINGE ESTIMATE. IT IS NOW 70%." }
  ],
  teachingPrompt: "Which scientific concept could help explain the experiment in this scene?",
  tags: ["story", "science", "comedy"]
};
