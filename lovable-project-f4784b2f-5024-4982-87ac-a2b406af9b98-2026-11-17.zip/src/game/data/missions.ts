import type { Mission } from "../types/game";
export const missions: Mission[] = [
  { id:"first-light", title:"First Light, Worst Text", subtitle:"A notification has collapsed the lab's emotional stability.", location:"Quantum Collider", concept:"Qubit states & measurement", difficulty:"beginner", reward:120, completed:true },
  { id:"double-date", title:"The Superposition Situation", subtitle:"Two possible Mayas. One very confused Leo.", location:"Interference Chamber", concept:"Hadamard gate & superposition", difficulty:"beginner", reward:180, completed:false },
  { id:"ex-files", title:"The Ex Files", subtitle:"Correlated outcomes. Uncorrelated communication.", location:"Ex Archives", concept:"Bell states & entanglement", difficulty:"intermediate", reward:260, completed:false },
  { id:"cold-shoulder", title:"Cold Shoulder Protocol", subtitle:"The processor is warmer than the group chat.", location:"Cryogenic Basement", concept:"Thermal noise & decoherence", difficulty:"intermediate", reward:320, completed:false },
  { id:"collision-course", title:"Collision Course", subtitle:"Reconstruct the missing particle from detector traces.", location:"Accelerator Ring", concept:"Energy & momentum conservation", difficulty:"advanced", reward:420, completed:false },
  { id:"phase-ghost", title:"The Phase Ghost", subtitle:"The probabilities look identical. The story does not.", location:"Forbidden Laboratory", concept:"Relative phase & interference", difficulty:"advanced", reward:520, completed:false }
];
