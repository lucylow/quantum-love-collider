import { createFileRoute } from "@tanstack/react-router";
import Screen from "@/game/views/Experiments";
export const Route = createFileRoute("/experiments")({
 head:()=>({meta:[{title:"Experiment Studio | The Quantum Love Collider"},{name:"description",content:"Create, save, import and export real quantum circuit experiments."},{property:"og:title",content:"Experiment Studio | The Quantum Love Collider"},{property:"og:description",content:"Create, save, import and export real quantum circuit experiments."},{property:"og:type",content:"website"},{name:"twitter:card",content:"summary_large_image"}]}),
 component:Screen,
});
