import { characters } from "../data/characters";
import { missions } from "../data/missions";
import { starterExperiments } from "../data/experiments";
const wait = (ms = 180) => new Promise(resolve => setTimeout(resolve, ms));
export const mockApi = {
  async getCharacters() { await wait(); return structuredClone(characters); },
  async getMissions() { await wait(); return structuredClone(missions); },
  async getExperiments() { await wait(); return structuredClone(starterExperiments); },
  async getLeaderboard() {
    await wait();
    return [
      { name:"QubitQueen", xp:4820, avatar:"👩‍🚀", rank:1 },
      { name:"SchrodingersCat", xp:3910, avatar:"🐈", rank:2 },
      { name:"MayaFanClub", xp:3270, avatar:"💗", rank:3 },
      { name:"You", xp:1240, avatar:"🧑‍🔬", rank:4 }
    ];
  }
};
