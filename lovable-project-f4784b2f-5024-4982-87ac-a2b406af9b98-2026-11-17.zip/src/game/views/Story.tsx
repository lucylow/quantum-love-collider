import Button from "../components/Button";
import { useState } from "react";
import { BookOpen, ChevronRight, Sparkles } from "lucide-react";
import { dialogueScenes } from "../data/dialogue";
import { missions } from "../data/missions";
import { useGameStore } from "../store";
import Panel from "../components/Panel";
export default function Story(){
 const [sceneIndex,setSceneIndex]=useState(0); const [choiceResult,setChoiceResult]=useState("");
 const {player,chooseStory,completeMission}=useGameStore(); const scene=dialogueScenes[sceneIndex];
 if(!scene) return null;
 return <div className="page-stack"><div className="section-intro"><div><div className="eyebrow">CAMPAIGN // CHAPTER 01</div><h2>One small text. <em>Infinite consequences.</em></h2><p>Choices influence the story and unlock different experiments. No relationship is literally a quantum state.</p></div><span className="pill pink-pill">BRANCHING NARRATIVE</span></div>
 <div className="story-layout"><Panel title="Incident transcript" eyebrow="CASE 014 // LIVE DIALOGUE"><div className="dialogue-scene"><div className="scene-number">SCENE 0{sceneIndex+1} / 02</div>{scene.lines.map((line,i)=><div className={`dialogue-line ${line.speaker.toLowerCase().includes("maya")?"pink":line.speaker.toLowerCase().includes("brad")?"cyan":""}`} key={i}><div className="dialogue-avatar">{line.speaker==="Maya"?"💗":line.speaker==="Evie"?"🧪":"🤖"}</div><div><b>{line.speaker}</b><p>{line.text}</p></div></div>)}</div><div className="choice-list"><div className="eyebrow">YOUR RESPONSE // SELECT ONE</div>{scene.choices.map((choice,i)=><Button className="choice-button" key={choice.id} onClick={()=>{chooseStory(scene.id,choice.id);setChoiceResult(choice.result);const m=missions.find(x=>x.id===choice.mission);if(m)completeMission(m.id,m.reward);}}><span>0{i+1}</span>{choice.label}<ChevronRight size={16}/></Button>)}</div>{choiceResult&&<div className="choice-result"><Sparkles size={16}/><span>{choiceResult}</span></div>}<div className="scene-controls"><Button className="button-ghost" onClick={()=>{setSceneIndex((sceneIndex+1)%dialogueScenes.length);setChoiceResult("");}}>Next scene <ChevronRight size={15}/></Button></div></Panel>
 <div className="story-side"><Panel title="Campaign progress" eyebrow="YOUR TIMELINE"><div className="chapter-progress"><div className="chapter-node complete">✓</div><div><b>Chapter 01 · First Contact</b><small>Collider orientation complete</small></div></div><div className="chapter-progress"><div className="chapter-node active">02</div><div><b>Chapter 02 · The Ex Files</b><small>Branching event detected</small></div></div><div className="chapter-progress"><div className="chapter-node">03</div><div><b>Chapter 03 · Decoherence</b><small>Locked · stabilize timeline</small></div></div></Panel><Panel title="Story variables" eyebrow="LOCAL SAVE"><div className="variable-row"><span>Choices recorded</span><b>{Object.keys(player.storyChoices).length}</b></div><div className="variable-row"><span>Missions completed</span><b>{player.completedMissions.length}</b></div><div className="variable-row"><span>Branching paths</span><b>03</b></div></Panel></div></div>
 </div>;
}
