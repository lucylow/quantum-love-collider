import type { Circuit } from "../../types/game";
export const caseData: Circuit = {
  id: "case-28",
  title: "Case 28: Interference Incident",
  description: "Use phase to make paths reinforce or cancel.",
  qubits: 1,
  gates: [
  {
    "id": "case-28-h",
    "type": "H",
    "target": 0
  }
],
  difficulty: "advanced"
};
export const learningObjective = "Amplitude addition";
export const facilitatorNote = "Ask the learner to predict the outcome before running the experiment. Then compare the prediction with the simulator output.";
