import type { PlayerState, Circuit } from "../types/game";
const PLAYER_KEY = "qlc-player-v1";
const EXPERIMENT_KEY = "qlc-experiments-v1";
export const defaultPlayer: PlayerState = {
  displayName:"Quantum Explorer", level:4, xp:1240, researchPoints:860, quantumShards:12,
  completedMissions:["first-light"], achievements:["first-gate","first-run"],
  inventory:[{id:"stabilizer",name:"Quantum Stabilizer",quantity:2},{id:"coffee",name:"Emergency Coffee",quantity:5}],
  selectedCharacter:"evie", storyChoices:{}
};
export function loadPlayer(): PlayerState {
  try { const raw = localStorage.getItem(PLAYER_KEY); return raw ? {...defaultPlayer,...JSON.parse(raw)} : defaultPlayer; }
  catch { return defaultPlayer; }
}
export function savePlayer(player: PlayerState) { localStorage.setItem(PLAYER_KEY, JSON.stringify(player)); }
export function loadExperiments(): Circuit[] {
  try { return JSON.parse(localStorage.getItem(EXPERIMENT_KEY) || "[]"); } catch { return []; }
}
export function saveExperiments(experiments: Circuit[]) { localStorage.setItem(EXPERIMENT_KEY, JSON.stringify(experiments)); }
export function clearDemoData() { localStorage.removeItem(PLAYER_KEY); localStorage.removeItem(EXPERIMENT_KEY); }
