import type { Circuit } from "../../types/game";
export const caseData: Circuit = {
  id: "case-18",
  title: "Case 18: Measurement Incident",
  description: "Convert squared amplitude magnitudes into outcome probabilities.",
  qubits: 2,
  gates: [
  {
    "id": "case-18-h",
    "type": "H",
    "target": 0
  },
  {
    "id": "case-18-cx",
    "type": "CNOT",
    "control": 0,
    "target": 1
  }
],
  difficulty: "intermediate"
};
export const learningObjective = "Born rule";
export const facilitatorNote = "Ask the learner to predict the outcome before running the experiment. Then compare the prediction with the simulator output.";
