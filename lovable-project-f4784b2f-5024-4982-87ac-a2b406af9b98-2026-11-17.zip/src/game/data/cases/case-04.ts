import type { Circuit } from "../../types/game";
export const caseData: Circuit = {
  id: "case-04",
  title: "Case 04: Interference Incident",
  description: "Apply H, Z, then H: destructive interference cancels |0⟩, leaving |1⟩ with certainty.",
  qubits: 1,
  gates: [
  {
    "id": "case-04-h",
    "type": "H",
    "target": 0
  },
  { id: "case-04-z", type: "Z", target: 0 },
  { id: "case-04-h2", type: "H", target: 0 }
],
  difficulty: "beginner"
};
export const learningObjective = "Amplitude addition";
export const facilitatorNote = "Ask the learner to predict the outcome before running the experiment. Then compare the prediction with the simulator output.";
