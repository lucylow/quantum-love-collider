export const achievements = [
  { id:"first-gate", title:"Gate Crasher", description:"Place your first quantum gate.", icon:"⚛️", points:25 },
  { id:"first-run", title:"Trust, But Verify", description:"Run your first circuit simulation.", icon:"🔬", points:50 },
  { id:"bell", title:"It's Complicated", description:"Build a Bell state.", icon:"💞", points:100 },
  { id:"five-experiments", title:"Lab Rat Energy", description:"Run five experiments.", icon:"🐀", points:125 },
  { id:"boss-one", title:"Kaiju Therapist", description:"Complete The Ick Kaiju encounter.", icon:"👾", points:200 },
  { id:"story-choice", title:"Choose Your Own Disaster", description:"Make a consequential story choice.", icon:"📖", points:75 }
];
