import type { Circuit } from "../../types/game";
export const caseData: Circuit = {
  id: "case-27",
  title: "Case 27: Entanglement Incident",
  description: "Create correlated outcomes using a controlled operation.",
  qubits: 2,
  gates: [
  {
    "id": "case-27-h",
    "type": "H",
    "target": 0
  },
  {
    "id": "case-27-cx",
    "type": "CNOT",
    "control": 0,
    "target": 1
  }
],
  difficulty: "advanced"
};
export const learningObjective = "Bell-state circuit";
export const facilitatorNote = "Ask the learner to predict the outcome before running the experiment. Then compare the prediction with the simulator output.";
