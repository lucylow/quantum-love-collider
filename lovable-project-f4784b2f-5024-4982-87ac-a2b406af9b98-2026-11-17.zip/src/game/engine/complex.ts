export interface Complex { re: number; im: number }
export const C = (re = 0, im = 0): Complex => ({ re, im });
export const add = (a: Complex, b: Complex): Complex => C(a.re + b.re, a.im + b.im);
export const sub = (a: Complex, b: Complex): Complex => C(a.re - b.re, a.im - b.im);
export const mul = (a: Complex, b: Complex): Complex => C(a.re*b.re - a.im*b.im, a.re*b.im + a.im*b.re);
export const scale = (a: Complex, n: number): Complex => C(a.re*n, a.im*n);
export const conj = (a: Complex): Complex => C(a.re, -a.im);
export const abs2 = (a: Complex): number => a.re*a.re + a.im*a.im;
export const magnitude = (a: Complex): number => Math.sqrt(abs2(a));
export const phase = (a: Complex): number => Math.atan2(a.im, a.re);
export const formatComplex = (a: Complex, digits = 3): string => {
  const re = Number(a.re.toFixed(digits));
  const im = Number(Math.abs(a.im).toFixed(digits));
  if (im === 0) return `${re}`;
  if (re === 0) return `${a.im < 0 ? "-" : ""}${im}i`;
  return `${re} ${a.im < 0 ? "-" : "+"} ${im}i`;
};
export const normalize = (v: Complex[]): Complex[] => {
  const norm = Math.sqrt(v.reduce((s, a) => s + abs2(a), 0));
  if (!Number.isFinite(norm) || norm < 1e-12) throw new Error("Cannot normalize a zero or invalid state.");
  return v.map(a => scale(a, 1/norm));
};
