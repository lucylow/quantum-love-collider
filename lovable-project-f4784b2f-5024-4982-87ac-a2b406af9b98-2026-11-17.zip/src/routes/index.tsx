import { createFileRoute } from "@tanstack/react-router";
import Screen from "@/game/views/Home";
export const Route = createFileRoute("/")({
 head:()=>({meta:[{title:"Command Overview | The Quantum Love Collider"},{name:"description",content:"Explore the laboratory, continue your story and run real quantum experiments."},{property:"og:title",content:"Command Overview | The Quantum Love Collider"},{property:"og:description",content:"Explore the laboratory, continue your story and run real quantum experiments."},{property:"og:type",content:"website"},{name:"twitter:card",content:"summary_large_image"}]}),
 component:Screen,
});
