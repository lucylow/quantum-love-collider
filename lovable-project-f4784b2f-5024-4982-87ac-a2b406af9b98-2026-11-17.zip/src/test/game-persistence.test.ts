import { beforeEach, describe, expect, it } from "vitest";
import { hydrateGame, useGameStore } from "../game/store";
import { circuitSchema } from "../game/engine/import-validation";
import type { Circuit } from "../game/types/game";

const circuit: Circuit = {id:"saved-test",title:"Saved test",description:"",qubits:2,gates:[{id:"x",type:"X",target:0}],difficulty:"beginner"};
beforeEach(()=> { localStorage.clear(); useGameStore.getState().resetDemo(); });
describe("Local demo persistence",()=> {
 it("reads back a saved experiment after hydration",()=> {
  useGameStore.getState().setActiveCircuit(circuit);
  useGameStore.getState().saveExperiment();
  useGameStore.setState({experiments:[]});
  hydrateGame();
  expect(useGameStore.getState().experiments).toEqual([circuit]);
 });
 it("awards each mission reward only once",()=> {
  const initial=useGameStore.getState().player.researchPoints;
  useGameStore.getState().completeMission("test-mission",180);
  useGameStore.getState().completeMission("test-mission",180);
  expect(useGameStore.getState().player.researchPoints).toBe(initial+180);
 });
 it("reset leaves unrelated browser data intact",()=> {
  localStorage.setItem("other-app","keep");
  useGameStore.getState().resetDemo();
  expect(localStorage.getItem("other-app")).toBe("keep");
 });
});
describe("Circuit import safety",()=> {
 it("accepts an exported valid circuit",()=> { expect(circuitSchema.parse(circuit)).toEqual(circuit); });
 it("rejects more than eight qubits",()=> {expect(circuitSchema.safeParse({...circuit,qubits:9}).success).toBe(false);});
 it("rejects more than 200 gates",()=> {expect(circuitSchema.safeParse({...circuit,gates:Array.from({length:201},(_,i)=>({id:String(i),type:"X",target:0}))}).success).toBe(false);});
 it("rejects a controlled gate targeting its control",()=> {expect(circuitSchema.safeParse({...circuit,gates:[{id:"bad",type:"CNOT",target:0,control:0}]}).success).toBe(false);});
});