export type Screen = "home" | "headquarters" | "circuit" | "characters" | "story" | "experiments" | "boss" | "profile";
export type GateType = "H" | "X" | "Y" | "Z" | "S" | "T" | "CNOT" | "CZ";
export type Difficulty = "beginner" | "intermediate" | "advanced";
export interface Gate {
  id: string;
  type: GateType;
  target: number;
  control?: number | undefined;
}
export interface Circuit {
  id: string;
  title: string;
  description: string;
  qubits: number;
  gates: Gate[];
  difficulty: Difficulty;
}
export interface Character {
  id: string; name: string; role: string; emoji: string; color: string;
  quirk: string; bio: string; specialty: string; quote: string;
  affinity: number; secrets: string[];
}
export interface Mission {
  id: string; title: string; subtitle: string; location: string;
  concept: string; difficulty: Difficulty; reward: number; completed: boolean;
}
export interface PlayerState {
  displayName: string; level: number; xp: number; researchPoints: number;
  quantumShards: number; completedMissions: string[]; achievements: string[];
  inventory: { id: string; name: string; quantity: number }[];
  selectedCharacter: string; storyChoices: Record<string, string>;
}
