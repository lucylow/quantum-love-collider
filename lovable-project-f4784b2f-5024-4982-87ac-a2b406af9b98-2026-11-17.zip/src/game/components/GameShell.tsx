import { useEffect, type ReactNode } from "react";
import { useLocation, useNavigate } from "@tanstack/react-router";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import { hydrateGame, registerGameNavigation, useGameStore } from "../store";
import { screenPaths } from "../navigation";
import type { Screen } from "../types/game";
export default function GameShell({children}:{children:ReactNode}) {
 const navigate=useNavigate(); const {pathname}=useLocation();
 useEffect(()=>{hydrateGame();},[]);
 useEffect(()=>{registerGameNavigation(screen=>{void navigate({to:screenPaths[screen]});});},[navigate]);
 useEffect(()=>{const screen=(Object.keys(screenPaths) as Screen[]).find(s=>screenPaths[s]===pathname); if(screen)useGameStore.setState({screen});},[pathname]);
 return <div className="app-shell"><Sidebar/><main className="main-area"><Topbar/><div className="page-content">{children}</div></main></div>;
}
