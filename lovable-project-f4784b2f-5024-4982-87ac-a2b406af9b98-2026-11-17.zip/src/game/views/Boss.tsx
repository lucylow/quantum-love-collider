import Button from "../components/Button";
import { useState } from "react";
import { ShieldAlert, Swords, Zap, Trophy } from "lucide-react";
import Panel from "../components/Panel";
const bosses=[
 {id:"ick",name:"The Ick Kaiju",emoji:"👾",level:"01 · INTRODUCTION",hp:72,challenge:"Create a superposition, then use a measurement prediction to stabilize the containment field.",concept:"Hadamard & measurement",reward:200},
 {id:"decoherence",name:"The Decoherence Demon",emoji:"👻",level:"02 · INTERMEDIATE",hp:48,challenge:"Explain why environmental noise can reduce interference visibility. Build a phase-sensitive circuit.",concept:"Noise & fidelity",reward:320},
 {id:"armada",name:"The Ex Armada",emoji:"💔",level:"03 · ADVANCED",hp:25,challenge:"Construct a two-qubit Bell state and identify its correlated measurement outcomes.",concept:"Multi-qubit entanglement",reward:450},
 {id:"entropy",name:"The Entropy Queen",emoji:"👑",level:"04 · ADVANCED",hp:10,challenge:"Compare reversible operations with information loss under measurement.",concept:"Entropy & measurement",reward:600}
];
export default function Boss(){
 const [active,setActive]=useState(bosses[0]);const [done,setDone]=useState<string[]>([]);
 if(!active) return null;
 return <div className="page-stack"><div className="section-intro"><div><div className="eyebrow">CONTAINMENT BREACH // COMBAT SIMULATION</div><h2>Boss <em>encounters.</em></h2><p>Bosses attack your circuit. Defeat them with scientific reasoning, not button mashing.</p></div><span className="pill pink-pill"><ShieldAlert size={12}/> 4 THREATS DETECTED</span></div>
 <div className="boss-layout"><div className="boss-list">{bosses.map(b=><Button className={`boss-select ${active.id===b.id?"selected":""}`} key={b.id} onClick={()=>setActive(b)}><span>{b.emoji}</span><div><b>{b.name}</b><small>{b.level}</small></div>{done.includes(b.id)&&<Trophy size={15}/>}</Button>)}</div>
 <div className="boss-arena"><div className="arena-grid"/><div className="boss-visual">{active.emoji}</div><div className="boss-label">HOSTILE ENTITY // {active.id.toUpperCase()}</div><h2>{active.name}</h2><div className="boss-health"><span>CONTAINMENT INTEGRITY</span><b>{active.hp}%</b><div><i style={{width:`${active.hp}%`}}/></div></div><Panel title="Scientific challenge" eyebrow="WEAPONIZED KNOWLEDGE"><p>{active.challenge}</p><div className="specialty"><Zap size={14}/>{active.concept}</div><div className="boss-reward">REWARD <b>+{active.reward} RP</b></div><Button className="button-primary full" onClick={()=>setDone(s=>s.includes(active.id)?s:[...s,active.id])}><Swords size={15}/> {done.includes(active.id)?"Encounter cleared":"Submit scientific solution"}</Button></Panel></div></div>
 </div>;
}
