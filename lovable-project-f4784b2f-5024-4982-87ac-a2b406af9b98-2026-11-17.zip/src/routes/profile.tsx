import { createFileRoute } from "@tanstack/react-router";
import Screen from "@/game/views/Profile";
export const Route = createFileRoute("/profile")({
 head:()=>({meta:[{title:"Player Profile | The Quantum Love Collider"},{name:"description",content:"Review your locally saved research progress, achievements and inventory."},{property:"og:title",content:"Player Profile | The Quantum Love Collider"},{property:"og:description",content:"Review your locally saved research progress, achievements and inventory."},{property:"og:type",content:"website"},{name:"twitter:card",content:"summary_large_image"}]}),
 component:Screen,
});
