import { createFileRoute } from "@tanstack/react-router";
import Screen from "@/game/views/Boss";
export const Route = createFileRoute("/boss")({
 head:()=>({meta:[{title:"Boss Encounters | The Quantum Love Collider"},{name:"description",content:"Explore the prototype scientific containment encounters."},{property:"og:title",content:"Boss Encounters | The Quantum Love Collider"},{property:"og:description",content:"Explore the prototype scientific containment encounters."},{property:"og:type",content:"website"},{name:"twitter:card",content:"summary_large_image"}]}),
 component:Screen,
});
