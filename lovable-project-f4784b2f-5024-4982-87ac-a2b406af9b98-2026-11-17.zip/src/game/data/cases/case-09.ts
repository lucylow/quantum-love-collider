import type { Circuit } from "../../types/game";
export const caseData: Circuit = {
  id: "case-09",
  title: "Case 09: Entanglement Incident",
  description: "Create correlated outcomes using a controlled operation.",
  qubits: 2,
  gates: [
  {
    "id": "case-09-h",
    "type": "H",
    "target": 0
  },
  {
    "id": "case-09-cx",
    "type": "CNOT",
    "control": 0,
    "target": 1
  }
],
  difficulty: "beginner"
};
export const learningObjective = "Bell-state circuit";
export const facilitatorNote = "Ask the learner to predict the outcome before running the experiment. Then compare the prediction with the simulator output.";
