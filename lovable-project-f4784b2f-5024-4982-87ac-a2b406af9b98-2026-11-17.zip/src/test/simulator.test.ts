import { describe, expect, it } from "vitest";
import { runCircuit } from "../game/engine/simulator";
import type { Circuit } from "../game/types/game";
describe("quantum state-vector simulator",()=>{
  it("starts in |0>",()=>{
    const c:Circuit={id:"a",title:"zero",description:"",qubits:1,gates:[],difficulty:"beginner"};
    expect(runCircuit(c).probabilities.find(p=>p.bitstring==="0")?.probability).toBeCloseTo(1);
  });
  it("creates a 50/50 superposition with H",()=>{
    const c:Circuit={id:"b",title:"H",description:"",qubits:1,gates:[{id:"h",type:"H",target:0}],difficulty:"beginner"};
    const r=runCircuit(c);
    expect(r.probabilities.find(p=>p.bitstring==="0")?.probability).toBeCloseTo(.5);
    expect(r.norm).toBeCloseTo(1);
  });
  it("creates a Bell state with H and CNOT",()=>{
    const c:Circuit={id:"c",title:"Bell",description:"",qubits:2,gates:[{id:"h",type:"H",target:0},{id:"cx",type:"CNOT",control:0,target:1}],difficulty:"intermediate"};
    const p=Object.fromEntries(runCircuit(c).probabilities.map(x=>[x.bitstring,x.probability]));
    expect(p["00"]).toBeCloseTo(.5); expect(p["11"]).toBeCloseTo(.5);
    expect(p["01"]??0).toBeCloseTo(0); expect(p["10"]??0).toBeCloseTo(0);
  });
  it("applies Pauli-X to flip |0> to |1>",()=>{
    const c:Circuit={id:"d",title:"X",description:"",qubits:1,gates:[{id:"x",type:"X",target:0}],difficulty:"beginner"};
    expect(runCircuit(c).probabilities[0]?.bitstring).toBe("1");
  });
  it("preserves normalization through the T phase gate",()=>{
    const c:Circuit={id:"t",title:"phase",description:"",qubits:1,gates:[{id:"h",type:"H",target:0},{id:"t",type:"T",target:0}],difficulty:"beginner"};
    const r=runCircuit(c);expect(r.norm).toBeCloseTo(1);expect(r.amplitudes[1]?.im).toBeCloseTo(.5);
  });
  it("displays the highest indexed qubit on the left",()=>{
    const c:Circuit={id:"order",title:"order",description:"",qubits:2,gates:[{id:"x",type:"X",target:0}],difficulty:"beginner"};
    expect(runCircuit(c).probabilities[0]?.bitstring).toBe("01");
  });
});
