# Quantum Love Collider import
- [x] Import all eight game screens and source content.
- [x] Preserve and test quantum simulation and local saves.
- [x] Verify desktop/mobile navigation and experiment workflow.

# Mock data improvements
- [x] Expand starter experiments with distinct educational circuits.
- [x] Correct phase, interference, and environment-coupling case data.
- [x] Verify dataset outcomes with the existing simulator.
