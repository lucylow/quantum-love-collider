import type { Screen } from "../types/game";
import Button from "../components/Button";
import { Atom, Snowflake, Archive, Coffee, LockKeyhole, Telescope, ArrowUpRight } from "lucide-react";
import { useGameStore } from "../store";
const rooms: {name:string;tag:string;desc:string;icon:typeof Atom;color:string;screen:Screen;status:string}[]=[
 {name:"Quantum Collider",tag:"MAIN EXPERIMENT FLOOR",desc:"Build circuits, manipulate qubits and attempt to keep the timelines from touching.",icon:Atom,color:"cyan",screen:"circuit",status:"ONLINE"},
 {name:"Cryogenic Basement",tag:"HARDWARE ENGINEERING",desc:"Keep superconducting qubits colder than Leo's last breakup.",icon:Snowflake,color:"blue",screen:"story",status:"RESTRICTED"},
 {name:"The Ex Archives",tag:"HISTORICAL INCIDENTS",desc:"Investigate previous relationship disasters and their suspiciously correlated outcomes.",icon:Archive,color:"pink",screen:"story",status:"ONLINE"},
 {name:"Particle Bar",tag:"SOCIAL EXPERIMENTS",desc:"Meet the crew. Order a Schrödinger's espresso. It may or may not arrive.",icon:Coffee,color:"amber",screen:"characters",status:"OPEN"},
 {name:"Forbidden Laboratory",tag:"EXPERIMENTAL ALGORITHMS",desc:"The door is locked for a reason. Probably Victor.",icon:LockKeyhole,color:"purple",screen:"experiments",status:"LOCKED"},
 {name:"Multiverse Observatory",tag:"TIMELINE ANALYSIS",desc:"Look at alternate endings without making eye contact with your choices.",icon:Telescope,color:"cyan",screen:"boss",status:"ONLINE"}
];
export default function Headquarters(){
 const setScreen=useGameStore(s=>s.setScreen);
 return <div className="page-stack"><div className="section-intro"><div><div className="eyebrow">FACILITY MAP // LEVEL -03</div><h2>Welcome to the <em>beautiful disaster.</em></h2><p>Choose a department to explore. Please do not feed the sentient detector.</p></div><div className="facility-badge"><span className="status-dot"/> 4 SYSTEMS OPERATIONAL</div></div>
 <div className="room-grid">{rooms.map((r,i)=>{const Icon=r.icon;return <Button className={`room-card ${r.color}`} key={r.name} onClick={()=>setScreen(r.screen)}><div className="room-top"><div className="room-icon"><Icon size={23}/></div><span className={`room-status ${r.status==="LOCKED"?"locked":""}`}>{r.status}</span></div><div className="eyebrow">{r.tag}</div><h3>{r.name}</h3><p>{r.desc}</p><div className="room-enter">ENTER DEPARTMENT <ArrowUpRight size={14}/></div><span className="room-number">0{i+1}</span></Button>})}</div>
 <div className="quote-banner"><span>“</span><p>The collider is not a dating app. It is a highly regulated scientific facility with a dating problem.</p><small>— DR. EVELYN SCHRÖDINGER, DIRECTOR OF DAMAGE CONTROL</small></div>
 </div>;
}
