import type { Circuit } from "../../types/game";
export const caseData: Circuit = {
  id: "case-07",
  title: "Case 07: Superposition Incident",
  description: "Prepare a qubit in an equal superposition and compare repeated measurements.",
  qubits: 1,
  gates: [
  {
    "id": "case-07-h",
    "type": "H",
    "target": 0
  }
],
  difficulty: "beginner"
};
export const learningObjective = "Hadamard gate";
export const facilitatorNote = "Ask the learner to predict the outcome before running the experiment. Then compare the prediction with the simulator output.";
