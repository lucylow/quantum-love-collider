import colliderImage from "@/assets/collider-lab.jpg";
import Button from "../components/Button";
import { ArrowUpRight, Atom, FlaskConical, Heart, Radio, ShieldAlert, Sparkles, Zap } from "lucide-react";
import { useGameStore } from "../store";
import { missions } from "../data/missions";
import { characters } from "../data/characters";
import Panel from "../components/Panel";
import ProgressBar from "../components/ProgressBar";
export default function Home(){
 const {player,setScreen,setActiveCircuit}=useGameStore();
 const next=missions.find(m=>!player.completedMissions.includes(m.id));
 return <div className="page-stack">
  <section className="hero-banner"><img className="hero-image" src={colliderImage} alt="The quantum collider and B.R.A.D. in the underground laboratory" width={1536} height={768}/><div className="hero-copy"><div className="hero-kicker"><span className="status-dot"/> COLLIDER STATUS: UNSTABLE, BUT CUTE</div><h2>The Quantum<br/><em>Love Collider.</em></h2><p>One lab. Five questionable scientists. Infinite ways to violate the laws of awkwardness.</p><div className="hero-actions"><Button className="button-primary" onClick={()=>setScreen("headquarters")}>Enter headquarters <ArrowUpRight size={16}/></Button><Button className="button-ghost" onClick={()=>setScreen("circuit")}>Open circuit lab</Button></div></div><div className="hero-index">CASE FILE // 014 <span>THE EX IS BACK</span></div></section>
  <div className="stats-grid">
   <div className="stat-card"><div className="stat-icon cyan"><Atom/></div><span>RESEARCH POINTS</span><strong>{player.researchPoints.toLocaleString()}</strong><small>+180 this session</small></div>
   <div className="stat-card"><div className="stat-icon pink"><Heart/></div><span>QUANTUM SHARDS</span><strong>{player.quantumShards}</strong><small>Rare lab currency</small></div>
   <div className="stat-card"><div className="stat-icon purple"><FlaskConical/></div><span>MISSIONS CLEARED</span><strong>{player.completedMissions.length}<i> / {missions.length}</i></strong><small>Campaign progress</small></div>
   <div className="stat-card"><div className="stat-icon amber"><Zap/></div><span>RESEARCH LEVEL</span><strong>{player.level}</strong><small>Senior-ish scientist</small></div>
  </div>
  <div className="content-grid two">
   <Panel title="Priority experiment" eyebrow="NEXT UP // RECOMMENDED" action={<span className="pill cyan-pill">BEGINNER</span>}>
    <div className="mission-feature"><div className="mission-symbol">🌀</div><div className="mission-info"><h4>{next?.title??"All caught up!"}</h4><p>{next?.subtitle??"You have stabilized the current timeline."}</p><div className="mission-meta"><span><Atom size={13}/> {next?.concept}</span><span><Sparkles size={13}/> +{next?.reward??0} RP</span></div></div></div>
    <Button className="button-primary full" onClick={()=>setScreen("story")}>Continue campaign <ArrowUpRight size={15}/></Button>
   </Panel>
   <Panel title="Containment monitor" eyebrow="LIVE SYSTEMS"><div className="system-list">
    {[["Quantum processor","Nominal · 15 mK",92,"cyan"],["Timeline integrity","Minor branching detected",68,"pink"],["Relationship stability","Please do not ask",31,"amber"]].map(([name,status,val,color])=><div className="system-row" key={String(name)}><div className="system-copy"><b>{name}</b><span>{status}</span></div><strong>{val}%</strong><ProgressBar value={Number(val)} color={String(color)}/></div>)}
   </div></Panel>
  </div>
  <Panel title="People of questionable judgment" eyebrow="YOUR CURRENT CREW" action={<Button className="text-action" onClick={()=>setScreen("characters")}>View all <ArrowUpRight size={14}/></Button>}>
   <div className="character-strip">{characters.slice(0,4).map(c=><Button className="character-mini" key={c.id} onClick={()=>setScreen("characters")}><div className="character-face" data-character={c.id}>{c.emoji}</div><div><b>{c.name}</b><small>{c.role}</small></div><span className="online-dot"/></Button>)}</div>
  </Panel>
  <div className="footer-note"><Radio size={13}/> DEMO SIMULATION ACTIVE <span>·</span> No real people were harmed in the creation of these quantum metaphors.</div>
 </div>;
}
