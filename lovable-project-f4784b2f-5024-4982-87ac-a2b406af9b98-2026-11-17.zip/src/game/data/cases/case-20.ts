import type { Circuit } from "../../types/game";
export const caseData: Circuit = {
  id: "case-20",
  title: "Case 20: Relative Phase: The Invisible Sign",
  description: "Apply H then Z: the |1⟩ amplitude changes sign while both measurement probabilities stay at 50%.",
  qubits: 1,
  gates: [
  {
    "id": "case-20-h",
    "type": "H",
    "target": 0
  },
  {
    "id": "case-20-cx",
    "type": "Z",
    "target": 0
  }
],
  difficulty: "intermediate"
};
export const learningObjective = "Z and phase gates";
export const facilitatorNote = "Ask the learner to predict the outcome before running the experiment. Then compare the prediction with the simulator output.";
