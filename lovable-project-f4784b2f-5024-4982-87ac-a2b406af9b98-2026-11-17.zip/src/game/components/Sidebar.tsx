import Button from "./Button";
import { Atom, FlaskConical, Users, BookOpen, Trophy, Home, CircuitBoard, Dna, UserRound, RotateCcw } from "lucide-react";
import { useGameStore } from "../store";
const nav = [
  {id:"home",label:"Overview",icon:Home},{id:"headquarters",label:"Headquarters",icon:Atom},
  {id:"circuit",label:"Circuit Lab",icon:CircuitBoard},{id:"characters",label:"Characters",icon:Users},
  {id:"story",label:"Story Missions",icon:BookOpen},{id:"experiments",label:"Experiment Studio",icon:FlaskConical},
  {id:"boss",label:"Boss Encounters",icon:Dna},{id:"profile",label:"Player Profile",icon:UserRound}
] as const;
export default function Sidebar() {
  const {screen,setScreen,player,resetDemo}=useGameStore();
  return <aside className="sidebar">
    <div className="brand"><div className="brand-mark"><Atom size={23}/></div><div><b>QUANTUM LOVE</b><small>COLLIDER // LAB OS</small></div></div>
    <div className="nav-label">COMMAND DECK</div>
    <nav>{nav.map(item=>{const Icon=item.icon;return <Button title={item.label} aria-label={item.label} key={item.id} onClick={()=>setScreen(item.id)} className={`nav-item ${screen===item.id?"active":""}`}><Icon size={17}/><span>{item.label}</span>{item.id==="circuit"&&<i className="nav-dot"/>}</Button>;})}</nav>
    <div className="sidebar-bottom">
      <div className="mini-profile"><div className="avatar">🧑‍🔬</div><div><b>{player.displayName}</b><small>LEVEL {player.level} RESEARCHER</small></div></div>
      <Button className="nav-item muted" onClick={resetDemo}><RotateCcw size={15}/><span>Reset demo data</span></Button>
      <div className="build-tag"><span className="status-dot"/> MOCK ENVIRONMENT · V1.0</div>
    </div>
  </aside>;
}
