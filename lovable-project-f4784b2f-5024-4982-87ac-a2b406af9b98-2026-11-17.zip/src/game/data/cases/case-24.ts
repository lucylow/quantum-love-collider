import type { Circuit } from "../../types/game";
export const caseData: Circuit = {
  id: "case-24",
  title: "Case 24: Measurement Incident",
  description: "Convert squared amplitude magnitudes into outcome probabilities.",
  qubits: 2,
  gates: [
  {
    "id": "case-24-h",
    "type": "H",
    "target": 0
  },
  {
    "id": "case-24-cx",
    "type": "CNOT",
    "control": 0,
    "target": 1
  }
],
  difficulty: "advanced"
};
export const learningObjective = "Born rule";
export const facilitatorNote = "Ask the learner to predict the outcome before running the experiment. Then compare the prediction with the simulator output.";
