import type { Circuit } from "../../types/game";
export const caseData: Circuit = {
  id: "case-22",
  title: "Case 22: Interference Incident",
  description: "Apply H, Z, then H: destructive interference cancels |0⟩, leaving |1⟩ with certainty.",
  qubits: 1,
  gates: [
  {
    "id": "case-22-h",
    "type": "H",
    "target": 0
  },
  { id: "case-22-z", type: "Z", target: 0 },
  { id: "case-22-h2", type: "H", target: 0 }
],
  difficulty: "advanced"
};
export const learningObjective = "Amplitude addition";
export const facilitatorNote = "Ask the learner to predict the outcome before running the experiment. Then compare the prediction with the simulator output.";
