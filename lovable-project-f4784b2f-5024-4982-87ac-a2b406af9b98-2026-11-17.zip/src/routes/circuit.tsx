import { createFileRoute } from "@tanstack/react-router";
import Screen from "@/game/views/CircuitLab";
export const Route = createFileRoute("/circuit")({
 head:()=>({meta:[{title:"Circuit Lab | The Quantum Love Collider"},{name:"description",content:"Build and simulate quantum circuits with up to eight qubits and inspect measurement probabilities."},{property:"og:title",content:"Circuit Lab | The Quantum Love Collider"},{property:"og:description",content:"Build and simulate quantum circuits with up to eight qubits and inspect measurement probabilities."},{property:"og:type",content:"website"},{name:"twitter:card",content:"summary_large_image"}]}),
 component:Screen,
});
