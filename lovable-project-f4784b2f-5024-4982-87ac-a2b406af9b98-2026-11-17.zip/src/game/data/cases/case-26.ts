import type { Circuit } from "../../types/game";
export const caseData: Circuit = {
  id: "case-26",
  title: "Case 26: Relative phase Incident",
  description: "Compare amplitudes, not only measurement probabilities, to understand phase.",
  qubits: 2,
  gates: [
  {
    "id": "case-26-h",
    "type": "H",
    "target": 0
  },
  {
    "id": "case-26-cx",
    "type": "CNOT",
    "control": 0,
    "target": 1
  }
],
  difficulty: "advanced"
};
export const learningObjective = "Z and phase gates";
export const facilitatorNote = "Ask the learner to predict the outcome before running the experiment. Then compare the prediction with the simulator output.";
