import { create } from "zustand";
import type { PlayerState, Screen, Circuit } from "./types/game";
import { defaultPlayer, loadPlayer, savePlayer, loadExperiments, saveExperiments, clearDemoData } from "./services/storage";
import { starterExperiments } from "./data/experiments";
interface GameStore {
  screen: Screen; player: PlayerState; experiments: Circuit[]; activeCircuit: Circuit;
  setScreen: (screen: Screen) => void; setActiveCircuit: (circuit: Circuit) => void;
  addGate: (type: Circuit["gates"][number]["type"], target: number, control?: number) => void;
  removeGate: (id: string) => void; setQubits: (n: number) => void;
  completeMission: (id: string, reward: number) => void;
  chooseStory: (scene: string, choice: string) => void;
  saveExperiment: () => void; resetDemo: () => void;
}
const blank: Circuit = starterExperiments[0] ?? {id:"blank",title:"Untitled experiment",description:"",qubits:2,gates:[],difficulty:"beginner"};
let navigateScreen: ((screen:Screen)=>void)|undefined;
export function registerGameNavigation(navigate:(screen:Screen)=>void){navigateScreen=navigate;}
export function hydrateGame(){useGameStore.setState({player:loadPlayer(),experiments:loadExperiments()});}
export const useGameStore = create<GameStore>((set,get) => ({
  screen:"home", player:structuredClone(defaultPlayer), experiments:[],
  activeCircuit:structuredClone(blank),
  setScreen:screen => {set({screen}); navigateScreen?.(screen);},
  setActiveCircuit:circuit => { set({activeCircuit:structuredClone(circuit),screen:"circuit"}); navigateScreen?.("circuit"); },
  addGate:(type,target,control) => set(s => ({activeCircuit:{...s.activeCircuit,gates:[...s.activeCircuit.gates,{id:crypto.randomUUID(),type,target,...(control===undefined?{}:{control})}]}})),
  removeGate:id => set(s => ({activeCircuit:{...s.activeCircuit,gates:s.activeCircuit.gates.filter(g=>g.id!==id)}})),
  setQubits:n => set(s => ({activeCircuit:{...s.activeCircuit,qubits:Math.max(1,Math.min(8,n)),gates:s.activeCircuit.gates.filter(g=>g.target<n && (g.control===undefined || g.control<n))}})),
  completeMission:(id,reward) => set(s => {
    if(s.player.completedMissions.includes(id)) return {};
    const player={...s.player,completedMissions:[...s.player.completedMissions,id],researchPoints:s.player.researchPoints+reward,xp:s.player.xp+reward};
    savePlayer(player); return {player};
  }),
  chooseStory:(scene,choice) => set(s => {
    const player={...s.player,storyChoices:{...s.player.storyChoices,[scene]:choice}};
    savePlayer(player); return {player};
  }),
  saveExperiment:() => set(s => {
    const existing=s.experiments.filter(e=>e.id!==s.activeCircuit.id);
    const experiments=[...existing,structuredClone(s.activeCircuit)];
    saveExperiments(experiments); return {experiments};
  }),
  resetDemo:() => { clearDemoData(); set({player:defaultPlayer,experiments:[],activeCircuit:structuredClone(blank),screen:"home"}); navigateScreen?.("home"); }
}));
