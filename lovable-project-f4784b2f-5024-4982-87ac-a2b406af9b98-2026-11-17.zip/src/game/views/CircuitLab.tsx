import Button from "../components/Button";
import { useMemo, useState } from "react";
import { Play, Plus, Trash2, Save, RotateCcw, Atom, Info, ChevronDown } from "lucide-react";
import { useGameStore } from "../store";
import { runCircuit, sampleShots } from "../engine/simulator";
import { validateCircuit } from "../engine/validation";
import { GATE_INFO } from "../engine/gates";
import type { GateType } from "../types/game";
import Panel from "../components/Panel";
const gateTypes: GateType[]=["H","X","Y","Z","S","T","CNOT","CZ"];
export default function CircuitLab(){
 const {activeCircuit,addGate,removeGate,setQubits,saveExperiment}=useGameStore();
 const [selectedTarget,setTarget]=useState(0); const [selectedControl,setControl]=useState(1);
 const target=Math.min(selectedTarget,activeCircuit.qubits-1); const control=Math.min(selectedControl,activeCircuit.qubits-1); const [shots,setShots]=useState(256);
 const [counts,setCounts]=useState<Record<string,number>|null>(null); const [error,setError]=useState("");
 const errors=useMemo(()=>validateCircuit(activeCircuit),[activeCircuit]);
 const result=useMemo(()=>{if(errors.length)return null;try{return runCircuit(activeCircuit)}catch{return null}},[activeCircuit,errors]);
 const run=()=>{if(!result){setError(errors.join(" "));return;}setError("");setCounts(sampleShots(result,shots));};
 return <div className="page-stack"><div className="section-intro"><div><div className="eyebrow">EXPERIMENT 014-A // STATE VECTOR ENGINE</div><h2>The quantum <em>switchboard.</em></h2><p>Build a circuit, run the simulation and inspect the probability distribution.</p></div><div className="simulation-status"><span className="status-dot"/> SIMULATOR READY</div></div>
 <div className="lab-toolbar"><div className="toolbar-name"><Atom size={17}/><b>{activeCircuit.title}</b><span className="pill cyan-pill">IDEAL SIMULATION</span></div><div className="toolbar-actions"><Button className="button-ghost small" onClick={()=>{setCounts(null);setError("");}}><RotateCcw size={14}/> Reset view</Button><Button className="button-ghost small" onClick={()=>{saveExperiment();setError("Experiment saved in this browser.");}}><Save size={14}/> Save experiment</Button><Button className="button-primary small" onClick={run}><Play size={14} fill="currentColor"/> Run circuit</Button></div></div>
 <div className="circuit-layout"><div className="circuit-main"><Panel title="Gate deck" eyebrow="DRAG-FREE QUICK INSERT"><div className="gate-deck">{gateTypes.map(type=><Button className={`gate-tile gate-${type.toLowerCase()}`} title={GATE_INFO[type].description} key={type} disabled={(type==="CNOT"||type==="CZ") && target===control} onClick={()=>addGate(type,target,type==="CNOT"||type==="CZ"?control:undefined)}><b>{GATE_INFO[type].symbol}</b><span>{type}</span></Button>)}</div><div className="insert-controls"><label>Target qubit<select value={target} onChange={e=>setTarget(Number(e.target.value))}>{Array.from({length:activeCircuit.qubits},(_,i)=><option key={i} value={i}>q{i}</option>)}</select></label><label>Control qubit<select value={control} onChange={e=>setControl(Number(e.target.value))}>{Array.from({length:activeCircuit.qubits},(_,i)=><option key={i} value={i}>q{i}</option>)}</select></label><span className="muted-copy">Choose a gate, then select its wire.</span></div></Panel>
 <Panel title="Circuit canvas" eyebrow={`${activeCircuit.qubits} QUBITS · ${activeCircuit.gates.length} GATES`} action={<div className="qubit-control"><Button onClick={()=>setQubits(activeCircuit.qubits-1)} disabled={activeCircuit.qubits<=1}>−</Button><b>{activeCircuit.qubits}</b><Button onClick={()=>setQubits(activeCircuit.qubits+1)} disabled={activeCircuit.qubits>=8}>+</Button></div>}>
 <div className="circuit-canvas">{Array.from({length:activeCircuit.qubits},(_,q)=><div className="wire-row" key={q}><span className="wire-label">q{q}</span><div className="wire-line"/><div className="wire-gates">{activeCircuit.gates.map((g,i)=>g.target===q||g.control===q?<div className={`placed-gate ${g.type==="CNOT"||g.type==="CZ"?"controlled":""}`} key={g.id} title={GATE_INFO[g.type].description}><b>{g.type==="CNOT"&&g.control===q?"●":g.type==="CNOT"?"⊕":g.type==="CZ"&&g.control===q?"●":g.type==="CZ"?"CZ":g.type}</b><Button aria-label="Remove gate" onClick={()=>removeGate(g.id)}>×</Button>{g.control===q&&<i className="control-stem"/>}</div>:<div className="gate-slot" key={g.id}/>)}</div></div>)}
 {activeCircuit.gates.length===0&&<div className="empty-circuit">Your circuit is a blank canvas. Add a gate to begin.</div>}</div>
 <div className="gate-sequence">{activeCircuit.gates.map((g,i)=><span key={g.id}>{i+1}. {g.type}{g.control!==undefined?` q${g.control}→q${g.target}`:` q${g.target}`}</span>)}</div>
 </Panel>
 {errors.length>0&&<div className="error-banner"><Info size={15}/>{errors.join(" ")}</div>}{error&&<div className="error-banner">{error}</div>}
 </div><div className="results-column"><Panel title="Measurement probabilities" eyebrow="IDEAL Z-BASIS DISTRIBUTION"><div className="probability-list">{result?.probabilities.filter(p=>p.probability>0.00001).map(p=><div className="prob-row" key={p.bitstring}><div className="prob-label">|{p.bitstring}⟩</div><div className="prob-track"><i style={{width:`${p.probability*100}%`}}/></div><b>{(p.probability*100).toFixed(1)}%</b></div>)??<p className="muted-copy">Fix circuit validation to view results.</p>}</div><div className="norm-check"><span>State norm</span><b>{result?.norm.toFixed(6)??"—"}</b><span className="norm-ok">● normalized</span></div></Panel>
 <Panel title="Shot sampler" eyebrow="STOCHASTIC MEASUREMENT"><label className="field-label">Number of shots<select value={shots} onChange={e=>setShots(Number(e.target.value))}><option value={64}>64 shots</option><option value={256}>256 shots</option><option value={1024}>1,024 shots</option><option value={4096}>4,096 shots</option></select></label><Button className="button-primary full" onClick={run}><Play size={14}/> Measure {shots.toLocaleString()} shots</Button>{counts&&<div className="shot-results">{Object.entries(counts).sort((a,b)=>b[1]-a[1]).map(([state,count])=><div className="shot-row" key={state}><span>|{state}⟩</span><div className="prob-track"><i style={{width:`${count/shots*100}%`}}/></div><b>{count}</b></div>)}</div>}</Panel>
 <div className="science-note"><Info size={15}/><p><b>Nerd Glasses mode:</b> this is an ideal state-vector simulation. Human relationship outcomes are not quantum measurements. Real devices add noise and calibration effects.</p></div>
 </div></div>
 </div>;
}
