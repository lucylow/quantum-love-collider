import { C, add, mul, scale, abs2, normalize, type Complex } from "./complex";
import { GATE_MATRICES } from "./gates";
import type { Circuit, Gate, GateType } from "../types/game";

export interface SimulationResult {
  amplitudes: Complex[];
  probabilities: { bitstring: string; probability: number }[];
  norm: number;
}
const validateQubits = (n: number) => {
  if (!Number.isInteger(n) || n < 1 || n > 8) throw new Error("This browser demo supports 1–8 qubits.");
};
const bit = (index: number, q: number) => (index >> q) & 1;
const setBit = (index: number, q: number, value: number) => value ? index | (1 << q) : index & ~(1 << q);
export const initialState = (qubits: number): Complex[] => {
  validateQubits(qubits);
  const state = Array.from({ length: 1 << qubits }, () => C());
  state[0] = C(1);
  return state;
};
function applySingle(state: Complex[], gate: Gate, type: Exclude<GateType, "CNOT" | "CZ">, qubits: number) {
  const matrix = GATE_MATRICES[type];
  const mask = 1 << gate.target;
  const output = state.map(a => C(a.re, a.im));
  for (let i = 0; i < state.length; i++) {
    if ((i & mask) !== 0) continue;
    const j = i | mask;
    const a=state[i], b=state[j];
    if(!a || !b) throw new Error("Invalid state vector.");
    output[i] = add(mul(matrix[0][0], a), mul(matrix[0][1], b));
    output[j] = add(mul(matrix[1][0], a), mul(matrix[1][1], b));
  }
  return output;
}
export function applyGate(state: Complex[], gate: Gate, qubits: number): Complex[] {
  if (gate.target < 0 || gate.target >= qubits) throw new Error("Gate target is outside the circuit.");
  if (gate.type === "CNOT" || gate.type === "CZ") {
    if (gate.control === undefined || gate.control < 0 || gate.control >= qubits || gate.control === gate.target)
      throw new Error("Controlled gates need a distinct, valid control qubit.");
    const out = state.map(a => C(a.re, a.im));
    for (let i = 0; i < state.length; i++) {
      if (!bit(i, gate.control)) continue;
      if (gate.type === "CNOT") {
        if (!bit(i, gate.target)) {
          const j = setBit(i, gate.target, 1);
          const a=state[i], b=state[j];
          if(!a || !b) throw new Error("Invalid state vector.");
          out[i] = C(b.re, b.im);
          out[j] = C(a.re, a.im);
        }
      } else if (bit(i, gate.target)) {
        const a=state[i];
        if(!a) throw new Error("Invalid state vector.");
        out[i] = scale(a, -1);
      }
    }
    return out;
  }
  return applySingle(state, gate, gate.type, qubits);
}
export function runCircuit(circuit: Circuit): SimulationResult {
  validateQubits(circuit.qubits);
  let state = initialState(circuit.qubits);
  for (const gate of circuit.gates) state = applyGate(state, gate, circuit.qubits);
  const probabilities = state.map((a, index) => ({
    bitstring: index.toString(2).padStart(circuit.qubits, "0"),
    probability: abs2(a)
  })).sort((a,b) => b.probability-a.probability);
  const norm = state.reduce((sum, a) => sum + abs2(a), 0);
  return { amplitudes: state, probabilities, norm };
}
export function sampleShots(result: SimulationResult, shots = 256): Record<string, number> {
  if (!Number.isInteger(shots) || shots < 1 || shots > 100000) throw new Error("Shots must be between 1 and 100,000.");
  const cumulative: { bitstring: string; limit: number }[] = [];
  let total = 0;
  result.probabilities.forEach(p => { total += p.probability; cumulative.push({ bitstring: p.bitstring, limit: total }); });
  const counts: Record<string, number> = {};
  for (let k = 0; k < shots; k++) {
    const r = Math.random() * total;
    const found = cumulative.find(p => r <= p.limit) ?? cumulative[cumulative.length-1];
    if(!found) throw new Error("No outcomes to sample.");
    counts[found.bitstring] = (counts[found.bitstring] ?? 0) + 1;
  }
  return counts;
}
export function probabilitiesByBitstring(result: SimulationResult) {
  return Object.fromEntries(result.probabilities.map(p => [p.bitstring, p.probability]));
}
