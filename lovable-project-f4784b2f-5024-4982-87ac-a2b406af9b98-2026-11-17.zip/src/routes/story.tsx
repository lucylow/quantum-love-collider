import { createFileRoute } from "@tanstack/react-router";
import Screen from "@/game/views/Story";
export const Route = createFileRoute("/story")({
 head:()=>({meta:[{title:"Story Missions | The Quantum Love Collider"},{name:"description",content:"Follow branching scientific adventures and record your choices."},{property:"og:title",content:"Story Missions | The Quantum Love Collider"},{property:"og:description",content:"Follow branching scientific adventures and record your choices."},{property:"og:type",content:"website"},{name:"twitter:card",content:"summary_large_image"}]}),
 component:Screen,
});
