import type { Circuit } from "../../types/game";
export const caseData: Circuit = {
  id: "case-30",
  title: "Case 30: Measurement Incident",
  description: "Convert squared amplitude magnitudes into outcome probabilities.",
  qubits: 2,
  gates: [
  {
    "id": "case-30-h",
    "type": "H",
    "target": 0
  },
  {
    "id": "case-30-cx",
    "type": "CNOT",
    "control": 0,
    "target": 1
  }
],
  difficulty: "advanced"
};
export const learningObjective = "Born rule";
export const facilitatorNote = "Ask the learner to predict the outcome before running the experiment. Then compare the prediction with the simulator output.";
