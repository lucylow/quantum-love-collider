export const dialogueScenes = [
  { id:"opening", character:"maya", lines:[
    { speaker:"Maya", text:"Okay. Nobody panic. The collider is reacting to my unread messages." },
    { speaker:"Evie", text:"That is not a recognized physical interaction." },
    { speaker:"B.R.A.D.", text:"I HAVE DETECTED 14,000 POSSIBLE OUTCOMES. EVERY SINGLE ONE IS EMBARRASSING." }
  ], choices:[
    { id:"wait", label:"Wait and gather more data.", result:"Patience selected. The lab's uncertainty remains bounded.", mission:"double-date" },
    { id:"ask", label:"Ask directly what happened.", result:"Direct communication selected. A new experiment is unlocked.", mission:"ex-files" },
    { id:"experiment", label:"Build a circuit and test the hypothesis.", result:"Science selected. Evie looks almost proud.", mission:"first-light" }
  ]},
  { id:"victor-warning", character:"victor", lines:[
    { speaker:"Victor", text:"You believe the circuit is random. It is not. You simply lack the full state description." },
    { speaker:"Evie", text:"That is an oversimplification of measurement, Victor." },
    { speaker:"Victor", text:"Then prove it." }
  ], choices:[
    { id:"challenge", label:"Challenge him to a Bell-state experiment.", result:"Victor accepts. The Ex Armada is alerted.", mission:"ex-files" },
    { id:"inspect", label:"Inspect the circuit for phase errors.", result:"You discover a hidden phase operation.", mission:"phase-ghost" }
  ]}
];
