import { describe, expect, it } from "vitest";
import { starterExperiments } from "../game/data/experiments";
import { case02, case04, case05 } from "../game/data/cases";
import { runCircuit, probabilitiesByBitstring } from "../game/engine/simulator";
import { circuitSchema } from "../game/engine/import-validation";

describe("educational mock circuits", () => {
  it("validates every starter and preserves normalization", () => {
    expect(new Set(starterExperiments.map(c => c.id)).size).toBe(starterExperiments.length);
    for (const circuit of starterExperiments) {
      expect(circuitSchema.safeParse(circuit).success).toBe(true);
      expect(runCircuit(circuit).norm).toBeCloseTo(1);
    }
  });
  it.each([
    ["double-h", { "0": 1 }],
    ["phase-to-bit", { "1": 1 }],
    ["anti-bell", { "01": .5, "10": .5 }],
    ["independent-coins", { "00": .25, "01": .25, "10": .25, "11": .25 }],
    ["ghz", { "000": .5, "111": .5 }],
    ["t-interference", { "0": (2 + Math.SQRT2) / 4, "1": (2 - Math.SQRT2) / 4 }],
  ])("computes %s from actual amplitudes", (id, expected) => {
    const circuit = starterExperiments.find(c => c.id === id);
    if (!circuit) throw new Error(`Missing experiment ${id}`);
    const probabilities = probabilitiesByBitstring(runCircuit(circuit));
    for (const [bits, probability] of Object.entries(expected)) expect(probabilities[bits]).toBeCloseTo(probability);
  });
  it("phase changes sign without changing measurement odds", () => {
    const result = runCircuit(case02);
    expect(result.amplitudes[1]?.re).toBeCloseTo(-Math.SQRT1_2);
    expect(probabilitiesByBitstring(result)["0"]).toBeCloseTo(.5);
  });
  it("interference cancels the zero outcome", () => {
    expect(probabilitiesByBitstring(runCircuit(case04))["1"]).toBeCloseTo(1);
  });
  it("the ideal environment model retains joint Bell correlations", () => {
    const p = probabilitiesByBitstring(runCircuit(case05));
    expect(p["00"]).toBeCloseTo(.5);
    expect(p["11"]).toBeCloseTo(.5);
    expect(p["01"]).toBeCloseTo(0);
    expect(p["10"]).toBeCloseTo(0);
  });
});
