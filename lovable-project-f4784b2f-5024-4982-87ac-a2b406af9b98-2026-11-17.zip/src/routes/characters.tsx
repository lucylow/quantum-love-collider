import { createFileRoute } from "@tanstack/react-router";
import Screen from "@/game/views/Characters";
export const Route = createFileRoute("/characters")({
 head:()=>({meta:[{title:"Characters | The Quantum Love Collider"},{name:"description",content:"Meet Evelyn, Maya, Leo, B.R.A.D. and Victor in the collider personnel files."},{property:"og:title",content:"Characters | The Quantum Love Collider"},{property:"og:description",content:"Meet Evelyn, Maya, Leo, B.R.A.D. and Victor in the collider personnel files."},{property:"og:type",content:"website"},{name:"twitter:card",content:"summary_large_image"}]}),
 component:Screen,
});
