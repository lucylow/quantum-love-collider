export default function ProgressBar({value,max=100,color="cyan"}:{value:number;max?:number;color?:string}){
 const width=Math.max(0,Math.min(100,(value/max)*100));
 return <div className={`progress-track ${color}`}><span style={{width:`${width}%`}}/></div>;
}
