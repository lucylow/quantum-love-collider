import type { Circuit, Gate } from "../types/game";
const SUPPORTED = new Set(["H","X","Y","Z","S","T","CNOT","CZ"]);
export function validateGate(gate: Gate, qubits: number): string[] {
  const errors: string[] = [];
  if (!SUPPORTED.has(gate.type)) errors.push("Unsupported gate type.");
  if (!Number.isInteger(gate.target) || gate.target < 0 || gate.target >= qubits) errors.push("Target qubit is invalid.");
  if (gate.type === "CNOT" || gate.type === "CZ") {
    if (gate.control === undefined || gate.control < 0 || gate.control >= qubits) errors.push("Control qubit is invalid.");
    if (gate.control === gate.target) errors.push("Control and target must differ.");
  }
  return errors;
}
export function validateCircuit(circuit: Circuit): string[] {
  const errors: string[] = [];
  if (!Number.isInteger(circuit.qubits) || circuit.qubits < 1 || circuit.qubits > 8) errors.push("Circuit must contain 1–8 qubits.");
  if (circuit.gates.length > 200) errors.push("Circuit exceeds the 200-gate demo limit.");
  circuit.gates.forEach((gate, index) => validateGate(gate, circuit.qubits).forEach(e => errors.push(`Gate ${index+1}: ${e}`)));
  return errors;
}
