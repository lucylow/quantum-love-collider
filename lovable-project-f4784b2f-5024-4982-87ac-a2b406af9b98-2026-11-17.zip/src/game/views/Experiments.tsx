import { circuitSchema } from "../engine/import-validation";
import Button from "../components/Button";
import { Download, Upload, Play, Plus, FlaskConical } from "lucide-react";
import { useRef } from "react";
import { starterExperiments } from "../data/experiments";
import { useGameStore } from "../store";
import Panel from "../components/Panel";
import { runCircuit } from "../engine/simulator";
export default function Experiments(){
 const {experiments,setActiveCircuit}=useGameStore(); const input=useRef<HTMLInputElement>(null);
 const all=[...starterExperiments.map(c=>experiments.find(e=>e.id===c.id)??c),...experiments.filter(e=>!starterExperiments.some(s=>s.id===e.id))];
 const exportCircuit=(c:typeof all[number])=>{const blob=new Blob([JSON.stringify(c,null,2)],{type:"application/json"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=`${c.id}.json`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);};
 const importCircuit=async(file?:File)=>{if(!file)return;try{const parsed=circuitSchema.parse(JSON.parse(await file.text()));setActiveCircuit(parsed);}catch(e){alert(e instanceof Error?e.message:"Import failed");}};
 return <div className="page-stack"><div className="section-intro"><div><div className="eyebrow">PERSONAL RESEARCH // LOCAL WORKSPACE</div><h2>Experiment <em>studio.</em></h2><p>Remix a starter experiment or import a circuit definition from a JSON file.</p></div><Button className="button-primary" onClick={()=>setActiveCircuit({id:crypto.randomUUID(),title:"Untitled experiment",description:"A new laboratory hypothesis.",qubits:2,gates:[],difficulty:"beginner"})}><Plus size={15}/> New experiment</Button></div>
 <div className="experiment-grid">{all.map(c=>{let probabilities: { bitstring: string; probability: number }[]=[];try{probabilities=runCircuit(c).probabilities.filter(p=>p.probability>0.001).slice(0,3)}catch{}return <article className="experiment-card" key={c.id}><div className="experiment-icon"><FlaskConical size={22}/></div><div className="eyebrow">{c.difficulty} // {c.qubits} QUBITS</div><h3>{c.title}</h3><p>{c.description}</p><div className="experiment-preview">{probabilities.map(p=><span key={p.bitstring}>|{p.bitstring}⟩ {(p.probability*100).toFixed(0)}%</span>)}</div><div className="experiment-actions"><Button className="button-primary small" onClick={()=>setActiveCircuit(c)}><Play size={13}/> Open lab</Button><Button className="icon-button" aria-label="Export experiment" onClick={()=>exportCircuit(c)}><Download size={15}/></Button></div></article>})}</div>
 <Panel title="Import a circuit" eyebrow="JSON EXPERIMENT FORMAT"><p className="muted-copy">Import a previously exported experiment. The circuit is validated when opened in the simulator.</p><input ref={input} type="file" accept="application/json,.json" hidden onChange={e=>importCircuit(e.target.files?.[0])}/><Button className="button-ghost" onClick={()=>input.current?.click()}><Upload size={15}/> Choose JSON file</Button></Panel>
 </div>;
}
