export const dialoguePack07 = {
  id: "dialogue-pack-07",
  title: "Collider incident transcript 07",
  lines: [
    { speaker: "Evie", text: "Let's define the system boundary before this becomes a metaphor." },
    { speaker: "Maya", text: "The system boundary is my patience, and it is not stable." },
    { speaker: "B.R.A.D.", text: "I HAVE UPDATED THE CRINGE ESTIMATE. IT IS NOW 75%." }
  ],
  teachingPrompt: "Which scientific concept could help explain the experiment in this scene?",
  tags: ["story", "science", "comedy"]
};
