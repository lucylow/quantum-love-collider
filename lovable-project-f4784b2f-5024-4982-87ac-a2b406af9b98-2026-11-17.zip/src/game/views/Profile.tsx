import Button from "../components/Button";
import { Award, Atom, Backpack, RotateCcw, Sparkles } from "lucide-react";
import { useGameStore } from "../store";
import { achievements } from "../data/achievements";
import Panel from "../components/Panel";
import ProgressBar from "../components/ProgressBar";
export default function Profile(){
 const {player,resetDemo}=useGameStore();
 return <div className="page-stack"><div className="section-intro"><div><div className="eyebrow">RESEARCHER RECORD // LOCAL PROFILE</div><h2>Your scientific <em>reputation.</em></h2><p>Progress is stored in this browser. Cloud synchronization is not connected in this demo.</p></div><Button className="button-ghost" onClick={resetDemo}><RotateCcw size={14}/> Reset demo</Button></div>
 <div className="profile-hero"><div className="profile-avatar">🧑‍🔬</div><div><div className="eyebrow">LEVEL {player.level} // EXPERIMENTALIST</div><h2>{player.displayName}</h2><p>Junior-ish scientist · Collider Division</p><div className="profile-xp"><ProgressBar value={player.xp%1500} max={1500}/><small>{player.xp%1500} / 1,500 XP to next level</small></div></div><div className="profile-total"><b>{player.xp.toLocaleString()}</b><small>TOTAL XP</small></div></div>
 <div className="content-grid two"><Panel title="Achievement cabinet" eyebrow="UNLOCKED RECOGNITION"><div className="achievement-grid">{achievements.map(a=>{const unlocked=player.achievements.includes(a.id);return <div className={`achievement ${unlocked?"unlocked":"locked"}`} key={a.id}><span>{unlocked?a.icon:"🔒"}</span><b>{a.title}</b><small>{unlocked?a.description:"Not unlocked yet"}</small></div>})}</div></Panel><Panel title="Inventory" eyebrow="BACKPACK // DEMO ITEMS"><div className="inventory-list">{player.inventory.map(item=><div className="inventory-item" key={item.id}><div><Backpack size={16}/><b>{item.name}</b></div><span>× {item.quantity}</span></div>)}</div></Panel></div>
 </div>;
}
