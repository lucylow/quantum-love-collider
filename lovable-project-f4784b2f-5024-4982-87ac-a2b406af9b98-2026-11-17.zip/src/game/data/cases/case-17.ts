import type { Circuit } from "../../types/game";
export const caseData: Circuit = {
  id: "case-17",
  title: "Case 17: Environment Coupling: Ideal Model",
  description: "Treat q0 as the system and q1 as its environment. H then CNOT entangles them: the joint state stays pure, while q0 alone is maximally mixed. This ideal circuit does not simulate a noise channel.",
  qubits: 2,
  gates: [
  {
    "id": "case-17-h",
    "type": "H",
    "target": 0
  },
  {
    "id": "case-17-cx",
    "type": "CNOT",
    "control": 0,
    "target": 1
  }
],
  difficulty: "intermediate"
};
export const learningObjective = "System–environment entanglement";
export const facilitatorNote = "Ask the learner to predict the outcome before running the experiment. Then compare the prediction with the simulator output.";
