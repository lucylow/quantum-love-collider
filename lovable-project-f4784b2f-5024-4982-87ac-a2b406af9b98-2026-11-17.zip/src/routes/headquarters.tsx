import { createFileRoute } from "@tanstack/react-router";
import Screen from "@/game/views/Headquarters";
export const Route = createFileRoute("/headquarters")({
 head:()=>({meta:[{title:"Headquarters | The Quantum Love Collider"},{name:"description",content:"Explore six departments of the Quantum Love Collider laboratory."},{property:"og:title",content:"Headquarters | The Quantum Love Collider"},{property:"og:description",content:"Explore six departments of the Quantum Love Collider laboratory."},{property:"og:type",content:"website"},{name:"twitter:card",content:"summary_large_image"}]}),
 component:Screen,
});
