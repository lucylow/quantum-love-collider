import { Heart, Lock, Sparkles } from "lucide-react";
import { characters } from "../data/characters";
import { useGameStore } from "../store";
import Panel from "../components/Panel";
export default function Characters(){
 const {player}=useGameStore();
 return <div className="page-stack"><div className="section-intro"><div><div className="eyebrow">PERSONNEL DATABASE // CLASSIFIED-ISH</div><h2>Meet the <em>lab specimens.</em></h2><p>Every genius has a specialty. Every specialist has baggage.</p></div><span className="pill purple-pill">5 ACTIVE PROFILES</span></div>
 <div className="people-grid">{characters.map(c=><article className="person-card" key={c.id}><div className="person-cover" data-character={c.id}><div className="person-glow"/><div className="person-emoji">{c.emoji}</div><span className="person-id">ID // {c.id.toUpperCase()}</span><span className="person-affinity"><Heart size={12}/>{c.affinity}%</span></div><div className="person-body"><div className="eyebrow">{c.role}</div><h3>{c.name}</h3><p>{c.bio}</p><div className="specialty"><Sparkles size={13}/>{c.specialty}</div><blockquote>“{c.quote}”</blockquote><div className="secret-list"><b>CLASSIFIED DETAILS</b>{c.secrets.map(s=><div key={s}><Lock size={11}/>{s}</div>)}</div></div></article>)}</div>
 <Panel title="Relationship telemetry" eyebrow="NON-SCIENTIFIC METRIC"><p className="muted-copy">Affinity is a narrative game variable, not a measurement of real human emotions. It changes dialogue branches and unlocks character scenes.</p><div className="affinity-list">{characters.map(c=><div className="affinity-row" key={c.id}><span>{c.emoji} {c.name}</span><div className="affinity-track"><i data-character={c.id} style={{width:`${c.affinity}%`}}/></div><b>{c.affinity}</b></div>)}</div></Panel>
 </div>;
}
