import { C, type Complex } from "./complex";
import type { GateType } from "../types/game";
export type Matrix2 = [[Complex, Complex], [Complex, Complex]];
const s = 1 / Math.sqrt(2);
export const GATE_MATRICES: Record<Exclude<GateType, "CNOT" | "CZ">, Matrix2> = {
  H: [[C(s), C(s)], [C(s), C(-s)]],
  X: [[C(0), C(1)], [C(1), C(0)]],
  Y: [[C(0), C(0,-1)], [C(0,1), C(0)]],
  Z: [[C(1), C(0)], [C(0), C(-1)]],
  S: [[C(1), C(0)], [C(0), C(0,1)]],
  T: [[C(1), C(0)], [C(0), C(Math.SQRT1_2, Math.SQRT1_2)]],
};
export const GATE_INFO: Record<GateType, { label: string; description: string; symbol: string }> = {
  H: { label: "Hadamard", description: "Creates an equal superposition from a basis state.", symbol: "H" },
  X: { label: "Pauli-X", description: "Bit flip: swaps |0⟩ and |1⟩.", symbol: "X" },
  Y: { label: "Pauli-Y", description: "Bit and phase flip with imaginary amplitudes.", symbol: "Y" },
  Z: { label: "Pauli-Z", description: "Phase flip on |1⟩; basis probabilities stay unchanged.", symbol: "Z" },
  S: { label: "S phase", description: "Adds a quarter-turn phase to |1⟩.", symbol: "S" },
  T: { label: "T phase", description: "Adds an eighth-turn phase to |1⟩.", symbol: "T" },
  CNOT: { label: "Controlled-NOT", description: "Flips the target when the control is |1⟩.", symbol: "⊕" },
  CZ: { label: "Controlled-Z", description: "Adds a minus sign to |11⟩ on the selected pair.", symbol: "CZ" }
};
