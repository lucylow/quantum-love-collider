import type { Screen } from "./types/game";
export const screenPaths = {home:"/",headquarters:"/headquarters",circuit:"/circuit",characters:"/characters",story:"/story",experiments:"/experiments",boss:"/boss",profile:"/profile"} as const satisfies Record<Screen,string>;
