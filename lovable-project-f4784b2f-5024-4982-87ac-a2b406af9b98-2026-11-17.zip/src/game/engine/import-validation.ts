import { z } from "zod";
import { validateCircuit } from "./validation";
export const circuitSchema = z.object({
 id:z.string().min(1).max(128),title:z.string().min(1).max(200),description:z.string().max(2000),
 qubits:z.number().int().min(1).max(8),difficulty:z.enum(["beginner","intermediate","advanced"]),
 gates:z.array(z.object({id:z.string().min(1),type:z.enum(["H","X","Y","Z","S","T","CNOT","CZ"]),target:z.number().int(),control:z.number().int().optional()})).max(200)
}).superRefine((c,ctx)=> { for(const message of validateCircuit(c)) ctx.addIssue({code:"custom",message}); });
